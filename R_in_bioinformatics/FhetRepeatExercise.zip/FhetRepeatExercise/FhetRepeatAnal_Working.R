library(tidyverse)

# read in the output from RepeatMasker modified to a tsv file
repdat <- read_tsv("fhet_dfam.tsv", col_names=TRUE)
glimpse(repdat)

# only choose the columns of output interested in
repdat.red <- repdat %>%
  select(query.sequence, pos.begin, pos.end, repeat.class.family, match.repeat) %>%
  arrange(query.sequence, pos.begin)
glimpse(repdat.red)
names(repdat.red)

repdat.red %>%
  select(repeat.class.family) %>%
  arrange() %>%
  unique() %>%
  view()

# read in the meta data on genome stats from NCBI
chromdat <- read_tsv("FhetGenomeSummary4p1.txt", col_names=TRUE, na="-")
view(chromdat)
names(chromdat)

# print out the Chrom and RefSeq info to use for later
chrom.labels <- chromdat %>%
  select(RefSeq, Chrom) %>%
  print(n=26)

# make a new variable called chron.num that simplifies the RefSeq code to chromosome number
# then add a column for the total length of the repeat
repdat.red.chrom <- repdat.red %>%
  mutate(Chrom = case_when(
    query.sequence == "NC_046361.1" ~ "Chr1",
    query.sequence == "NC_046362.1" ~ "Chr2",
    query.sequence == "NC_046363.1" ~ "Chr3", 
    query.sequence == "NC_046364.1" ~ "Chr4", 
    query.sequence == "NC_046365.1" ~ "Chr5", 
    query.sequence == "NC_046366.1" ~ "Chr6", 
    query.sequence == "NC_046367.1" ~ "Chr7", 
    query.sequence == "NC_046368.1" ~ "Chr8", 
    query.sequence == "NC_046369.1" ~ "Chr9", 
    query.sequence == "NC_046370.1" ~ "Chr10",
    query.sequence == "NC_046371.1" ~ "Chr11",
    query.sequence == "NC_046372.1" ~ "Chr12",
    query.sequence == "NC_046373.1" ~ "Chr13",
    query.sequence == "NC_046374.1" ~ "Chr14",
    query.sequence == "NC_046375.1" ~ "Chr15",
    query.sequence == "NC_046376.1" ~ "Chr16",
    query.sequence == "NC_046377.1" ~ "Chr17",
    query.sequence == "NC_046378.1" ~ "Chr18",
    query.sequence == "NC_046379.1" ~ "Chr19",
    query.sequence == "NC_046380.1" ~ "Chr20",
    query.sequence == "NC_046381.1" ~ "Chr21",
    query.sequence == "NC_046382.1" ~ "Chr22",
    query.sequence == "NC_046383.1" ~ "Chr23",
    query.sequence == "NC_046384.1" ~ "Chr24",
    query.sequence == "NC_012312.1" ~ "MT",   
    TRUE ~ "Unk")) %>%
  mutate(repeat.length = (pos.end - pos.begin))
head(repdat.red.chrom)


# how many different query.sequences are there?
tmp <- repdat.red %>%
  select(query.sequence) %>%
  group_by(query.sequence) %>%
  summarise(n = n())
# this tells me that there are over a 1000 contigs, only 24 chromsomes, and we do not know the total size of 1000-24 unknown contigs


# calculate the total count and number of bp of each repeat family on each chromosome
te.chrom.stats <- repdat.red.chrom %>%
  group_by(Chrom, repeat.class.family) %>%
  summarise(
    NumCopies = n(),
    total.bp = sum(repeat.length))
head(te.chrom.stats)

# make a new column identifying type of TE or not a TE
# filter to remove all non-TE
te.chrom.dat <- te.chrom.stats %>% 
  mutate(te.class = case_when(
   str_detect(repeat.class.family , "DNA.*") ~  "dnatrans",
    str_detect(repeat.class.family, "LINE.*")  ~  "line",
    str_detect(repeat.class.family, "LTR.*")  ~  "ltr",
    str_detect(repeat.class.family, "SINE.*")  ~  "sine",
    str_detect(repeat.class.family, "RC.*")  ~  "rchel",
    TRUE ~ "non_te")) %>%
  filter(!te.class == "non_te")
glimpse(te.chrom.dat)

# plot for one type of TE
# first create some order vectors for Chromo to cuntomize
# must be a more efficient way to do this

# chrom.order <- c("Chr1", "Chr2", "Chr3", "Chr4", "Chr5", "Chr6","Chr7", "Chr8", "Chr9", "Chr10","Chr11", "Chr12", "Chr13", "Chr14", "Chr15", "Chr16","Chr17", "Chr18", "Chr19", "Chr20","Chr21", "Chr22", "Chr23", "Chr24", "Unk" )
# chrom.order.rev <- c("Unk", "Chr24", "Chr23", "Chr22",  "Chr21", "Chr20","Chr19", "Chr18", "Chr17", "Chr16","Chr15", "Chr14", "Chr13", "Chr12", "Chr11", "Chr10","Chr9", "Chr8",  "Chr7", "Chr6","Chr5","Chr4", "Chr3", "Chr2","Chr1")
chrom.order.rev <- c("Chr24", "Chr23", "Chr22",  "Chr21", "Chr20","Chr19", "Chr18", "Chr17", "Chr16","Chr15", "Chr14", "Chr13", "Chr12", "Chr11", "Chr10","Chr9", "Chr8",  "Chr7", "Chr6","Chr5","Chr4", "Chr3", "Chr2","Chr1")

# now plot a simple bar-chart without the unassigned contigs

te.chrom.dat %>% 
  filter(repeat.class.family == "LINE_L2" & !Chrom == "Unk") %>%
  mutate(Chrom = factor(Chrom, levels=chrom.order.rev)) %>%
  ggplot(aes(x = Chrom, y=NumCopies)) +
#  geom_bar(stat="identity") +
  geom_point(cex=5, color="blue") +
  coord_flip() +
  theme_bw()


ggplot(bp_plot) +
  geom_point(aes(x = gene_ratio, y = GO_term, , color = p.value), 
             size = 2) +
  theme_bw()





# with the unassigned contigs
te.chrom.dat %>% 
  filter(repeat.class.family == "LINE_L2") %>%
  mutate(Chrom = factor(Chrom, levels=chrom.order.rev)) %>%
  ggplot(aes(x = Chrom, y=NumCopies)) +
  geom_bar(stat="identity") +
  coord_flip()





# pivot wider to merge with metadata
tmp <- tmp %>%
  pivot_wider(names_from = repeat.class.family, values_from = NumCopies)
view(tmp)
dim(tmp)

# merge with genome metadata
alldata <- left_join(tmp, chromdat, by="Chrom")
dim(alldata)
dim(chromdat)
names(alldata)

glimpse(alldata)


# TO DO: aggregate all major TE classes, e.g. DNA transposons, LINEs, SINEs, etc
# calulate percentage of genome by calculating the total length of TEs and divide by length of chromosome
# various plots of TE vs other variables in metadata 
  
  
# do we pivot longer or not?

