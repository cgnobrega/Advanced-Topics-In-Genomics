fhet_chrom_counts.txt - number nucleotides making up all chromosomes and contigs from Fhet genome 

fhet_dfam.out - table output from RepeatMasker listing all repeat elements in Fhet genome

fhet_dfam.tsv - fhet_dfam.out converted to BED-file-like with headers modified. R compatable

fhet_repmodmasked.tsv - all repeates from RepeatModeler from masked genome input, with headers modified. R compatable

fhet_genome_contigs.txt - all headers from fhet genome fasta file

fhet_masked_denovo.tsv - table output from RepeatMasker listing all repeat elements in Fhet genome from masked genome

fhet_repmodmasked.tsv - table output from RepeatMasker listing all repeat elements in Fhet genome from masked genome

FhetGenomeSummary4p1.txt - chromosome stats for Fhet genome from NCBI table

headerinfo.tsv - standard header information used in conversion from RepeatMasker output to  tsv file for input into R
