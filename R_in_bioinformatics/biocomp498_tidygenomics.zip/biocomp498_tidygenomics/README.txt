data from Introduction to R for Biologists
Maria Doyle, Jessica Chung, Vicky Perreau

18 October 2020

RNASeq dataset with multiple samples; RNA-seq data from the paper by Fu et al. 2015, GEO code GSE60450. This study examined expression in basal and luminal cells from mice at different stages (virgin, pregnant and lactating). There are 2 samples per group and 6 groups, 12 samples in total.
