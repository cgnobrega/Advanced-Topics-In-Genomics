# CART - Classification and Regression Tree (rpart)

# setwd("~/Desktop/iris_CART")					# or whatever directory you are working in

library(rpart)	

# how many observations must be present at a node before a split is created on that node 
minimumSplit  <- 10								
# minimum number of observations that can be found in a leaf node
minimumBucket <- minimumSplit/3					


indata <- read.csv("iris.csv", header=FALSE)	# read the input file into indata

# just build a MODEL with all the data
fit <- rpart(V1 ~ V2 + V3 + V4 + V5, method="class", data=indata, 
             control=rpart.control(minsplit = minimumSplit, minBucket = minimumBucket) )

plot(fit, uniform=TRUE, main="CART for Iris Data")		# plot the model
text(fit, use.n=TRUE, all=TRUE, cex=.8)				 	      # make it look a bit nicer

# ------------------------------------------------------------------------
# split up TRAINing (x%) and TESTing ( (100-x)% ) sets
TrainPercent = 0.80
# (a) build a MODEL with training set
# (b) test (predict) efficacy of model using test set

set.seed(as.integer(Sys.time()))				# set the seed for a random generator using the current time

rand   <- sample(nrow(indata))					# generate a random order for indata's rows
indata <- indata[rand,]							    # scramble indata based on this random order

# store a mapping between classifications and original line numbers or row names
correctAnswers <- indata[1]		

# split into Training and Testing sets

N <- nrow(indata)
Ntrain <- as.integer( TrainPercent*N )
Ntest  <- (N - Ntrain)

# recall indata has already been randomly shuffled; slice Testing and Training sets
testSet  <- indata[1:Ntest, ]
trainSet <- indata[Ntest+1:N, ]

# time to build a MODEL (using only Training Set)
					
fit <- rpart(V1 ~ V2 + V3 + V4 + V5, method="class", data=trainSet, control=rpart.control(minsplit = minimumSplit, minBucket = minimumBucket) )

plot(fit, uniform=TRUE, main="CART for Iris Data (training)")		# plot the model
text(fit, use.n=TRUE, all=TRUE, cex=.8)				 	                # make it look a bit nicer
# post(fit, file="CART_iris.ps", title="CART for Iris Data")		# output a file of the plot

# make predictions using model on the Test Set
preds <- predict(fit, testSet)							# predict classifications for the test data

# check how we did on the predictions
predFrame  <- as.data.frame(preds)
predCols   <- colnames(predFrame)		# get the possible predicted values
corCount   <- 0							        # initialize the number correct to 0
wrongCount <- 0							        # initialize the number wrong to 0

print("--- Test ---------------------------------------")
for(j in 1:nrow(predFrame))						# loop over each prediction
{
		rowNum <- row.names(predFrame[j, ])		# find the row name
		maxCol <- which.max(predFrame[j,])		# find which value the instance was predicted to be
		
		# if the predicted value matches the actual classification

		if(correctAnswers[rowNum,] == predCols[maxCol])				{
			corCount <- corCount + 1				
		}
		else
		{
			wrongCount <- wrongCount + 1
			msg <- paste("WRONG(actual:pred) - [", rowNum, correctAnswers[rowNum,], "] :", predCols[maxCol], sep=" ")
			print(msg)
		}
	
	} # for each prediction

print(sprintf("Train on %2d rows; Test with others: %2d", Ntrain, Ntest)) 
print(sprintf("  Number correct is: %2d", corCount)) 
print(sprintf("  Number wrong is: %2d",   wrongCount)) 
corCount <- corCount / (corCount+wrongCount)			  # calculate the average correct 
print(sprintf("  Percent correct is %3.2f", corCount*100))	





