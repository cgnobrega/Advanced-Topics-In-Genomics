# CART - Classification and Regression Tree (rpart)
# using k-fold validation

library(rpart)									

set.seed(as.integer(Sys.time()))              # set the seed for a random generator using the current time

indata <- read.csv("iris.csv", header=FALSE)	# read the input file into indata
rand   <- sample(nrow(indata))					      # generate a random order for indata's rows

print("Shuffling rows of data ...")
indata <- indata[rand,]							          # scramble indata based on this random order

# store a mapping between classifications and original line numbers or row names(classData is a data frame)
classData <- indata[1]							

minimumSplit <- 10								# set the minSplit to be 10
minimumBucket <- minimumSplit/3		# minBucket will be 3

k <- 10									    # use k=10 folds for validation
numElems <- nrow(indata)/k	# find the size of each fold
valid <- 0	                # total correct across all k-folds

for(i in 1:k)	# loop once for each fold
{
  print(sprintf("-------- Test (k=%02d)------------------", i)) 
	testData  <- indata[(i*numElems-numElems+1):(i*numElems), ]	# pull out the TEST fold
	modelData <- indata[1:(i*numElems-numElems) , ]			        # pull out everything BEFORE the test data for the model
	temp <- indata[(i*numElems+1):nrow(indata), ]		            # pull out everything AFTER the test data
	modelData <- rbind(modelData, temp)				                  #      and put bind together to  model

	print(sprintf("Testing rows [%d, %d]", (i*numElems-numElems+1), (i*numElems) ))
	
	# create the model using modelData
	fit <- rpart(V1 ~ V2 + V3 + V4 + V5, method="class", data=modelData, control=rpart.control(minsplit = minimumSplit, minBucket = minimumBucket) )
	#plot(fit, uniform=TRUE, main="CART for Iris")           	# plot the model
	#text(fit, use.n=TRUE, all=TRUE, cex=.8)				            # make it look a bit nicer
	#post(fit, file="tree.ps", title="CART for Iris Data")		# output a file of the plot

	preds <- predict(fit, testData)					# predict classifications for the test data
	predFrame <- as.data.frame(preds)				# store it in a data frame
	predCols <- colnames(predFrame)					# get the possible predicted values
	
	corCount   <- 0						# per fold, initialize the number correct to 0
	wrongCount <- 0						# per fold, initialize the number wrong to 0

	for(j in 1:nrow(predFrame))					# loop over each prediction
	{
		rowNum <- row.names(predFrame[j, ])			# find the row name
		maxCol <- which.max(predFrame[j,])			# find which value the instance was predicted to be

		#print(classData[rowNum,])
		#print(predCols[maxCol])
		#readline()

		if(classData[rowNum,] == predCols[maxCol])		# if the predicted value matches the actual classification
		{
			corCount <- corCount + 1;				# update the correct count
		}
		else
		{
			wrongCount <- wrongCount + 1
			msg <- paste("WRONG([actual] : pred) - ( [", rowNum, classData[rowNum,],"] :", predCols[maxCol], ")", sep=" ")
			print(msg)
		}
	
	}

	print(sprintf("Number correct is: %2d", corCount)) 
	print(sprintf("Number wrong is: %2d",   wrongCount)) 
	proportionCorrect <- corCount / (corCount+wrongCount)			# calculate proportion correct for this fold
	print(sprintf("Percent correct is %.2f", proportionCorrect*100)) 
	print("------------------------------------------------")
	#readline("Pause...")
	

	#valid <- valid + corCount				
}

print(sprintf("%d folds with %d tests per fold.", k, numElems))

# good place to report some stats over all the folds tested ...
# you do it? :)

 