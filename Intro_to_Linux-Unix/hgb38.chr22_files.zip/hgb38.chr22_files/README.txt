
README.txt : this file


hg.b38.chr22.fa : Chr22 genome in fasta format

hgb38.chr22.GenesNCBI.GFF3 : annotation of Chr22 based on GenBank 

hgb38.chr22.RepeatsRepeatMasker.BED : location of transposable elements on Chr22 from RepeatMasker as BED format

hgb38.chr22.GenesEnsembl.GFF3 : annotation of Chr22 from Ensembl; same annotations, slightly different information provided
