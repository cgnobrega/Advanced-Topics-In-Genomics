# using a browser, down a zipped-tarball at:
http://cs.wheatoncollege.edu/mleblanc/LinuxPart2.tar.gz

# if you need to make your own tar ball of a directory
% tar cvf LinuxPart2.tar LinuxPart_2
# now zip up the tar ball
% gzip LinuxPart2.tar
# you’ll now have a file called:  LinuxPart_2.tar.gz

# to unzip, then un-tar (extract) 
% gunzip LinuxPart2.tar.gz
% tar xvf LinuxPart2.tar

# -----------------------------------------
# number of lines of original data?
% wc Mayer_2754BBacteriaGenusCounts.csv   # default wc (no options) reports: line     word	bytes
     241     242    5195 Mayer_2754BBacteriaGenusCounts.csv

% wc -l Mayer_2754BBacteriaGenusCounts.csv 
     241 Mayer_2754BBacteriaGenusCounts.csv
# -----------------------------------------ss

% head -3 Mayer_2754BBacteriaGenusCounts.csv 
name,P.SC4CapeCod-28F,P.SC1Norton-28F
Algoriphagus,569,63
Solirubrobacter,3,3

% cut -f3 -d"," Mayer_2754BBacteriaGenusCounts.csv

% cut -f3 -d"," Mayer_2754BBacteriaGenusCounts.csv | head -2
P.SC1Norton-28F
63

% cut -f3 -d"," Mayer_2754BBacteriaGenusCounts.csv | sort

# UGH ... (we need numeric, inverted sort)
% cut -f3 -d"," Mayer_2754BBacteriaGenusCounts.csv | sort -nr | head -6
316
252
…
# HMMM, but what genus is this?
# swap columns so column #3(Norton) will be in front, … then sort will work?
% awk '{FS=OFS=","; name=$1; $1=$3; $3=name;} {print}' Mayer_2754BBacteriaGenusCounts.csv | head -3
,,name,P.SC4CapeCod-28F,P.SC1Norton-28F
63,569,Algoriphagus
3,3,Solirubrobacter

# now let's see top 2 from Norton
% awk '{FS=","; OFS=" "; name=$1; $1=$3; $3=name;} {print}' Mayer_2754BBacteriaGenusCounts.csv | sort -nr | head -2 
316 0 Niastella
252 0 Aminobacter
…
# -----------------------------------------
# remove ambiguous classification lines (e.g., Joostella::Flavobacterium,1,0)

% grep "::" Mayer_2754BBacteriaGenusCounts.csv 
% grep "::" Mayer_2754BBacteriaGenusCounts.csv | less

% grep -v "::" Mayer_2754BBacteriaGenusCounts.csv 
 
% grep -v "::" Mayer_2754BBacteriaGenusCounts.csv > noColonMayer.csv
Mayer_2754BBacteriaGenusCounts.csv	noColonMayer.csv

# how many remaining?
% wc -l noColonMayer.csv 
190 noColonMayer.csv
# -----------------------------------------
# remove singletons:     1,0   or    0,1
% grep -v ",0,1$" noColonMayer.csv > noZeroOne.csv

% wc -l noZeroOne.csv 
164 noZeroOne.csv

% grep -v ",1,0$" noZeroOne.csv > finalDATA.csv

% wc -l finalDATA.csv 
155 finalDATA.csv



1


