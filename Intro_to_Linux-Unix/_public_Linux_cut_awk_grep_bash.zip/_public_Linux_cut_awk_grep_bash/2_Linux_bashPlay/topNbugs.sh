#!/bin/bash

# top-most Norton bacteria

# bash script to process files one at a time;
# here, we 
# cull singletons in data, and sort by
# the largest numerical value
# then use awk to flip columns 3 (Norton bacterial)
# and 1 (the bacteria name),

# ** presently sorts for Norton column (3)
# ** needs refactor to handle ANY column, with a cmd-line arg

# .csv: bacterialCounts,CapeCodMA,NortonMA
# header and sample line:
#   name,P.SC4CapeCod-28F,P.SC1Norton-28F
#   Algoriphagus,569,63

FILES="./data/*.csv"

for nextFile in $FILES
do
  echo "==================================="
  echo "Processing $nextFile"

  # remove ambiguous classification lines (find :: in line)
  grep -v "::" $nextFile > noColonMayer.csv

  # remove singletons in the data:  1,0  and  0,1
  grep -v ",0,1$" noColonMayer.csv > noZeroOne.csv
  grep -v ",1,0$" noZeroOne.csv > finalDATA.csv

  # head -10 finalDATA.csv

  # (1) awk to flip columns | (2) sort numerically

  # now take action on each file
  # use awk to flip columns 1 and 3,
  #    .csv on input (FS), space separated on output (OFS)

  awk '{FS=","; OFS=" "; name=$1; $1=$3; $3=name;} {print}' finalData.csv | sort -nr | head -3
  echo "-----------------------------------"

done

echo " "
echo "Done."
