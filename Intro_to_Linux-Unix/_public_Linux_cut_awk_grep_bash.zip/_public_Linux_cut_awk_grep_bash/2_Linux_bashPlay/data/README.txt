just test dataset, original file split in two to make 3 tests

original:
Mayer_2754BBacteriaGenusCounts.csv

Mayer_2754BBacteriaGenusCounts_1.csv
Mayer_2754BBacteriaGenusCounts_2.csv
